@echo off
title PharmaDrug
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PharmaDrug-Server.ps1"
