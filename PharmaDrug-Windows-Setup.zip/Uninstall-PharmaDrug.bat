@echo off
title PharmaDrug Uninstall
echo Removing PharmaDrug shortcuts and files...
set "TARGET=%LOCALAPPDATA%\PharmaDrug"
del /f /q "%USERPROFILE%\Desktop\PharmaDrug.lnk" 2>nul
del /f /q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\PharmaDrug.lnk" 2>nul
if exist "%TARGET%" rd /s /q "%TARGET%"
echo Done. You can close this window.
pause
