@echo off
title PharmaDrug Setup
cd /d "%~dp0"
echo.
echo  ========================================
echo   PharmaDrug - Windows Setup
echo  ========================================
echo.
set "TARGET=%LOCALAPPDATA%\PharmaDrug"
echo Installing to:
echo   %TARGET%
echo.

if not exist "%TARGET%" mkdir "%TARGET%"
xcopy /E /I /Y "PharmaDrug\*" "%TARGET%\" >nul
copy /Y "Launch-PharmaDrug.bat" "%TARGET%\Launch-PharmaDrug.bat" >nul
copy /Y "PharmaDrug-Server.ps1" "%TARGET%\PharmaDrug-Server.ps1" >nul
copy /Y "Uninstall-PharmaDrug.bat" "%TARGET%\Uninstall-PharmaDrug.bat" >nul

:: Desktop shortcut
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$t=[Environment]::GetFolderPath('Desktop');" ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $t 'PharmaDrug.lnk'));" ^
  "$s.TargetPath='%TARGET%\Launch-PharmaDrug.bat';" ^
  "$s.WorkingDirectory='%TARGET%';" ^
  "$s.Description='PharmaDrug - Pharmacology Drug Database';" ^
  "$s.WindowStyle=7;" ^
  "$s.IconLocation='%SystemRoot%\System32\shell32.dll,14';" ^
  "$s.Save()"

:: Start Menu shortcut (Programs)
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$t=Join-Path ([Environment]::GetFolderPath('StartMenu')) 'Programs';" ^
  "if (!(Test-Path $t)) { New-Item -ItemType Directory -Path $t | Out-Null };" ^
  "$s=(New-Object -ComObject WScript.Shell).CreateShortcut((Join-Path $t 'PharmaDrug.lnk'));" ^
  "$s.TargetPath='%TARGET%\Launch-PharmaDrug.bat';" ^
  "$s.WorkingDirectory='%TARGET%';" ^
  "$s.Description='PharmaDrug - Pharmacology Drug Database';" ^
  "$s.WindowStyle=7;" ^
  "$s.IconLocation='%SystemRoot%\System32\shell32.dll,14';" ^
  "$s.Save()"

echo.
echo  Install complete.
echo  - Desktop shortcut: PharmaDrug
echo  - Start Menu: type PharmaDrug
echo.
echo  Launching PharmaDrug now...
echo.
start "" "%TARGET%\Launch-PharmaDrug.bat"
timeout /t 3 >nul
exit /b 0
