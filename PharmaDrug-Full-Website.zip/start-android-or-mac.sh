#!/usr/bin/env bash
cd "$(dirname "$0")"
echo "PharmaDrug — starting local server on http://127.0.0.1:8080"
if command -v python3 >/dev/null 2>&1; then
  (sleep 1; command -v xdg-open >/dev/null && xdg-open "http://127.0.0.1:8080/index.html" || open "http://127.0.0.1:8080/index.html" 2>/dev/null) &
  python3 -m http.server 8080
elif command -v npx >/dev/null 2>&1; then
  npx --yes serve -l 8080
else
  echo "Need python3 or npx to run the installable server."
  exit 1
fi
