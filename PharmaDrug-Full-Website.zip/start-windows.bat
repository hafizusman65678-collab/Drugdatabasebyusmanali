@echo off
title PharmaDrug Server
cd /d "%~dp0"
echo.
echo  PharmaDrug — starting local server...
echo.

where py >nul 2>nul
if %ERRORLEVEL%==0 (
  start "" "http://127.0.0.1:8080/index.html"
  py -m http.server 8080
  goto :eof
)

where python >nul 2>nul
if %ERRORLEVEL%==0 (
  start "" "http://127.0.0.1:8080/index.html"
  python -m http.server 8080
  goto :eof
)

where npx >nul 2>nul
if %ERRORLEVEL%==0 (
  start "" "http://127.0.0.1:8080"
  npx --yes serve -l 8080
  goto :eof
)

echo Python or Node.js is required to install as an app.
echo Install Python from https://www.python.org/downloads/
echo Then double-click this file again.
pause
